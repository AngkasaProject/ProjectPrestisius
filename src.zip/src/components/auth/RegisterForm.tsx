import { useState } from "react";
import { supabase } from "@/lib/supabase/client";

export default function RegisterForm() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setLoading(true);
    setMessage("");

    const form = new FormData(e.currentTarget);

    const email = String(form.get("email"));
    const password = String(form.get("password"));
    const fullName = String(form.get("full_name"));
    const username = String(form.get("username"));
    const confirmPassword = String(form.get("confirm_password"));

    if (password !== confirmPassword) {
      setMessage("Password confirmation does not match.");
      setLoading(false);
      return;
    }
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      setMessage(error.message);
      setLoading(false);
      return;
    }
    const user = data.user;

    if (!user) {
      setMessage("Failed to create account.");
      setLoading(false);
      return;
    }

    const { error: profileError } = await supabase.from("profiles").insert({
      id: user.id,
      full_name: fullName,
      username,
    });

    if (profileError) {
      setMessage(profileError.message);
      setLoading(false);
      return;
    }
    window.location.href = "/admin";
  }

  return (
    <form onSubmit={handleSubmit} className="mt-10 space-y-5">
      <div>
        <label className="mb-2 block text-sm font-medium">Full Name</label>

        <input
          name="full_name"
          type="text"
          required
          placeholder="John Doe"
          className="h-12 w-full rounded-xl border border-zinc-200 px-4 outline-none focus:border-zinc-900"
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium">Username</label>

        <input
          name="username"
          type="text"
          required
          placeholder="johndoe"
          className="h-12 w-full rounded-xl border border-zinc-200 px-4 outline-none focus:border-zinc-900"
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium">Email</label>

        <input
          name="email"
          type="email"
          required
          placeholder="you@example.com"
          className="h-12 w-full rounded-xl border border-zinc-200 px-4 outline-none focus:border-zinc-900"
        />
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium">Password</label>

        <input
          name="password"
          type="password"
          required
          minLength={6}
          placeholder="••••••••"
          className="h-12 w-full rounded-xl border border-zinc-200 px-4 outline-none focus:border-zinc-900"
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium">
          Confirm Password
        </label>

        <input
          name="confirm_password"
          type="password"
          required
          minLength={6}
          placeholder="••••••••"
          className="h-12 w-full rounded-xl border border-zinc-200 px-4 outline-none focus:border-zinc-900"
        />
      </div>

      <button
        disabled={loading}
        className="flex h-12 w-full items-center justify-center rounded-xl bg-zinc-900 font-medium text-white transition hover:bg-zinc-800 disabled:opacity-50"
      >
        {loading ? "Creating account..." : "Register"}
      </button>

      {success && (
        <p className="text-center text-sm text-emerald-600">
          Account created successfully.
        </p>
      )}

      {message && <p className="text-center text-sm text-red-500">{message}</p>}
    </form>
  );
}
